import json
import os
import uuid # For generating unique IDs
import traceback

DATA_FILE = 'data.json'
site_data = {}

# --- File I/O Functions ---
def load_data():
    global site_data
    full_path = os.path.abspath(DATA_FILE)
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                site_data = json.load(f)
            print(f"Data loaded successfully from '{full_path}'.")
        except json.JSONDecodeError:
            print(f"Error: '{full_path}' contains invalid JSON. Initializing with default data.")
            initialize_default_data()
            save_data()
        except Exception as e:
            print(f"Error loading data from '{full_path}': {e}. Initializing with default data.")
            initialize_default_data()
            save_data()
    else:
        print(f"Warning: '{full_path}' not found. Initializing with default data structure.")
        initialize_default_data()
        save_data()

def initialize_default_data():
    global site_data
    site_data = {
        "siteConfig": {
            "persistentHeaderMessage": "Welcome to our Store!",
            "telegramBotLink": "https://t.me/Tyrell_TheForgottenOne", # Default full URL
            "developerTelegramLink": "https://t.me/Tyrell_TheForgottenOne" # Default full URL
        },
        "products": [],
        "paymentMethods": [
            {
                "id": "kpay",
                "name": "KPay Transfer",
                "instructions": {
                    "accountName": "Your KPay Registered Name",
                    "accountNumber": "08X-XXX-XXXX",
                    "notes": "Please include your email address or order reference in the payment details."
                }
            },
            {
                "id": "binance",
                "name": "Binance (UID Payment)",
                "instructions": {
                    "uid": "YOUR_BINANCE_UID_PLACEHOLDER",
                    "currency": "USDT only",
                    "notes": "A transaction screenshot is highly recommended. Please ensure you are sending to the correct UID."
                }
            }
        ],
        "adminNote": {
            "title": "Important Admin Note",
            "isVisible": True,
            "content": [
                "This is a default admin note. Please edit it using the content manager."
            ]
        },
        "faq": [
            {
                "id": generate_id("faq_"),
                "question": "How do I make a purchase?",
                "answer": "Browse our products, select a plan, and follow the payment instructions. Contact us on Telegram for delivery."
            }
        ]
    }
    print("Initialized with default data structure.")


def save_data():
    full_path = os.path.abspath(DATA_FILE)
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(site_data, f, indent=2, ensure_ascii=False)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass 
        print(f"Data successfully saved to '{full_path}'.")
        print("IMPORTANT: Refresh your website and editor to see changes.")
    except Exception as e:
        print(f"CRITICAL ERROR saving data to '{full_path}': {e}")
        traceback.print_exc()

# --- Helper Functions ---
def get_input(prompt_text, default_value=None, required=False):
    while True:
        current_value_display = ""
        if default_value is not None:
            current_value_display = f" (current: '{default_value}')" if str(default_value).strip() else " (current: empty)"
        
        full_prompt = f"{prompt_text}{current_value_display}: "
        user_input = input(full_prompt).strip()

        if not user_input and default_value is not None:
            return default_value 
        if required and not user_input:
            print("This field is required. Please enter a value.")
            continue
        return user_input

def get_int_input(prompt_text, default_value=None, required=False, min_val=None, max_val=None):
    while True:
        val_str = get_input(prompt_text, default_value=str(default_value) if default_value is not None else None, required=required)
        if not val_str and default_value is not None:
             return default_value
        if not val_str and not required:
            return None 
        try:
            val_int = int(val_str)
            if min_val is not None and val_int < min_val:
                print(f"Value must be at least {min_val}.")
                continue
            if max_val is not None and val_int > max_val:
                print(f"Value must be at most {max_val}.")
                continue
            return val_int
        except ValueError:
            print("Invalid input. Please enter a whole number.")

def get_float_input(prompt_text, default_value=None, required=False, min_val=0.0):
    while True:
        val_str = get_input(prompt_text, default_value=str(default_value) if default_value is not None else None, required=required)
        if not val_str and default_value is not None:
            return default_value
        if not val_str and not required:
            return None
        try:
            val_float = float(val_str)
            if min_val is not None and val_float < min_val:
                print(f"Value must be at least {min_val:.2f}.")
                continue
            return val_float
        except ValueError:
            print("Invalid input. Please enter a decimal number (e.g., 10.99).")

def get_bool_input(prompt_question, current_bool_value, true_meaning="Yes (True)", false_meaning="No (False)"):
    current_state_display = true_meaning if current_bool_value else false_meaning
    suggested_action_if_enter_bool = not current_bool_value
    suggested_action_display = true_meaning if suggested_action_if_enter_bool else false_meaning
    full_prompt = f"{prompt_question}? (Currently: {current_state_display}) (yes/no) [Enter to change to '{suggested_action_display}']: "
    while True:
        user_input = input(full_prompt).strip().lower()
        if not user_input: 
            return not current_bool_value
        if user_input in ['y', 'yes']:
            return True
        elif user_input in ['n', 'no']:
            return False
        else:
            print("Invalid input. Please enter 'yes' or 'no', or press Enter to toggle.")

def display_menu(title, options, show_exit=True):
    print(f"\n--- {title} ---")
    for i, option_text in enumerate(options, 1):
        print(f"{i}. {option_text}")
    exit_option_num = len(options) + 1
    if show_exit:
        print(f"{exit_option_num}. Back to Previous Menu / Exit")
    while True:
        try:
            choice_str = input("Enter your choice: ")
            if not choice_str: continue
            choice = int(choice_str)
            max_choice = exit_option_num if show_exit else len(options)
            if 1 <= choice <= max_choice:
                return choice
            else:
                print(f"Invalid choice. Please select a number between 1 and {max_choice}.")
        except ValueError:
            print("Invalid input. Please enter a number.")

def generate_id(prefix="item_"):
    return prefix + str(uuid.uuid4().hex)[:8]

def find_item_by_id(item_list, item_id, id_key='id'):
    for item in item_list:
        if item.get(id_key) == item_id:
            return item
    return None

# --- Site Config Management --- 
def manage_site_config():
    if 'siteConfig' not in site_data: 
        site_data['siteConfig'] = {}
    config_ref = site_data['siteConfig']
    
    print("\n--- Edit Site Configuration ---")
    made_change = False
    
    new_val = get_input("Persistent Header Message", default_value=config_ref.get('persistentHeaderMessage', ''), required=True)
    if new_val != config_ref.get('persistentHeaderMessage'): 
        config_ref['persistentHeaderMessage'] = new_val
        made_change = True
    
    # MODIFIED PROMPT for telegramBotLink
    new_val = get_input(
        "Telegram Bot URL for Order Receipt (e.g., https://t.me/YourBotName or t.me/YourBotName)", 
        default_value=config_ref.get('telegramBotLink', 'https://t.me/Tyrell_TheForgottenOne'), 
        required=True
    )
    if new_val != config_ref.get('telegramBotLink'): 
        config_ref['telegramBotLink'] = new_val
        made_change = True

    # MODIFIED PROMPT for developerTelegramLink
    new_val = get_input(
        "Developer Contact Telegram URL (for footer if used by JS, e.g., https://t.me/YourDevName or t.me/YourDevName)", 
        default_value=config_ref.get('developerTelegramLink', 'https://t.me/Tyrell_TheForgottenOne'), 
        required=True
    )
    if new_val != config_ref.get('developerTelegramLink'): 
        config_ref['developerTelegramLink'] = new_val
        made_change = True
    
    if made_change:
        print("Site configuration updated, saving...")
        save_data()
    else:
        print("No changes made to site configuration.")

# --- Admin Note Management --- 
def manage_admin_note():
    if 'adminNote' not in site_data or not isinstance(site_data['adminNote'], dict):
        site_data['adminNote'] = {"title": "Default Admin Note", "isVisible": True, "content": []}
    admin_note_ref = site_data['adminNote']

    while True:
        print("\n--- Current Admin Note ---")
        print(f"Title: {admin_note_ref.get('title', 'Not Set')}")
        print(f"Visible: {'Yes' if admin_note_ref.get('isVisible', True) else 'No'}")
        print("Content:")
        current_content = admin_note_ref.get('content', [])
        if current_content:
            for i, p in enumerate(current_content): print(f"  {i+1}. {p}")
        else: print("  (No content yet)")

        options = ["Edit Title", "Toggle Visibility", "Edit a Paragraph", "Add a Paragraph", "Remove a Paragraph"]
        choice = display_menu("Admin Note Management", options)
        made_change = False

        if choice == 1: 
            new_val = get_input("New Title", default_value=admin_note_ref.get('title', ''), required=True)
            if new_val != admin_note_ref.get('title'): admin_note_ref['title'] = new_val; made_change = True
        elif choice == 2: 
            current_val = admin_note_ref.get('isVisible', True)
            new_val = get_bool_input("Set Admin Note to Visible", current_bool_value=current_val, true_meaning="Visible", false_meaning="Hidden")
            if new_val != current_val: admin_note_ref['isVisible'] = new_val; made_change = True
        elif choice == 3: 
            if not current_content: print("No paragraphs to edit."); continue
            for i, p in enumerate(current_content): print(f"  {i+1}. {p}")
            para_num = get_int_input("Paragraph number to edit", required=True, min_val=1, max_val=len(current_content))
            if para_num:
                old_text = current_content[para_num-1]
                new_text = get_input(f"New text for paragraph {para_num}", default_value=old_text, required=True)
                if new_text != old_text: admin_note_ref['content'][para_num-1] = new_text; made_change = True
        elif choice == 4: 
            new_para = get_input("Enter new paragraph text", required=True)
            if not isinstance(admin_note_ref.get('content'), list): admin_note_ref['content'] = []
            admin_note_ref['content'].append(new_para); made_change = True
        elif choice == 5: 
            if not current_content: print("No paragraphs to remove."); continue
            for i, p in enumerate(current_content): print(f"  {i+1}. {p}")
            para_num = get_int_input("Paragraph number to remove", required=True, min_val=1, max_val=len(current_content))
            if para_num:
                confirm = get_bool_input(f"Remove paragraph {para_num}: '{current_content[para_num-1][:30]}...'?", current_bool_value=False, true_meaning="Yes, Remove", false_meaning="No, Keep")
                if confirm: admin_note_ref['content'].pop(para_num-1); print("Paragraph removed."); made_change = True
        elif choice == 6: break
        
        if made_change: print("Admin Note change detected, saving..."); save_data()
        elif choice != len(options) + 1: print("No changes were made to Admin Note.")

# --- FAQ Management ---
def manage_faqs():
    if 'faq' not in site_data or not isinstance(site_data['faq'], list): site_data['faq'] = []
    faqs_list_ref = site_data['faq']

    while True:
        print("\n--- Current FAQs ---")
        if not faqs_list_ref: print("No FAQs yet.")
        else:
            for i, faq_item in enumerate(faqs_list_ref): print(f"{i+1}. Q: {faq_item.get('question', 'N/A')} (ID: {faq_item.get('id', 'N/A')})")
        options = ["Add New FAQ", "Edit Existing FAQ", "Remove FAQ"]
        choice = display_menu("FAQ Management", options)
        made_change = False

        if choice == 1: 
            question = get_input("Enter the new question", required=True)
            answer = get_input("Enter the answer", required=True)
            new_faq_id = generate_id("faq_");
            while any(f.get('id') == new_faq_id for f in faqs_list_ref): new_faq_id = generate_id("faq_")
            faqs_list_ref.append({"id": new_faq_id, "question": question, "answer": answer})
            print(f"New FAQ (ID: {new_faq_id}) added."); made_change = True
        elif choice == 2: 
            if not faqs_list_ref: print("No FAQs to edit."); continue
            print("\n--- Select FAQ to Edit ---")
            for i, faq_item in enumerate(faqs_list_ref): print(f"{i+1}. Q: {faq_item.get('question', 'N/A')}")
            faq_num = get_int_input("Enter number of FAQ to edit", required=True, min_val=1, max_val=len(faqs_list_ref))
            if faq_num:
                faq_to_edit = faqs_list_ref[faq_num-1] 
                print(f"\nEditing FAQ (ID: {faq_to_edit.get('id')}):")
                old_q, new_q = faq_to_edit.get('question'), get_input("New question", default_value=faq_to_edit.get('question'))
                if new_q != old_q: faq_to_edit['question'] = new_q; made_change = True
                old_a, new_a = faq_to_edit.get('answer'), get_input("New answer", default_value=faq_to_edit.get('answer'))
                if new_a != old_a: faq_to_edit['answer'] = new_a; made_change = True
                if made_change: print("FAQ updated.")
                else: print("No changes made to this FAQ.")
        elif choice == 3: 
            if not faqs_list_ref: print("No FAQs to remove."); continue
            print("\n--- Select FAQ to Remove ---")
            for i, faq_item in enumerate(faqs_list_ref): print(f"{i+1}. Q: {faq_item.get('question', 'N/A')}")
            faq_num = get_int_input("Enter number of FAQ to remove", required=True, min_val=1, max_val=len(faqs_list_ref))
            if faq_num:
                faq_to_remove = faqs_list_ref[faq_num-1]
                confirm = get_bool_input(f"Remove FAQ: '{faq_to_remove.get('question', '')[:30]}...'?", current_bool_value=False, true_meaning="Yes, Remove", false_meaning="No, Keep")
                if confirm: faqs_list_ref.pop(faq_num-1); print("FAQ removed."); made_change = True
        elif choice == 4: break
        
        if made_change: print("FAQ change detected, saving..."); save_data()
        elif choice != len(options) + 1: print("No changes were made to FAQs for that action.")

# --- Payment Method Management ---
def manage_payment_methods():
    if 'paymentMethods' not in site_data or not isinstance(site_data['paymentMethods'], list):
        site_data['paymentMethods'] = []
    payment_methods_ref = site_data['paymentMethods']

    while True:
        print("\n--- Payment Method Management ---")
        if not payment_methods_ref:
            print("No payment methods configured.")
            input("Press Enter to return to main menu.")
            break
        
        print("Current Payment Methods:")
        for i, method in enumerate(payment_methods_ref):
            print(f"  {i+1}. {method.get('name', 'Unnamed Method')} (ID: {method.get('id', 'N/A')})")
        
        exit_option_num = len(payment_methods_ref) + 1
        print(f"  {exit_option_num}. Back to Main Menu")
        
        choice = get_int_input("Select a payment method to edit (or choose 'Back')", required=True, min_val=1, max_val=exit_option_num)

        if choice == exit_option_num: break

        selected_method_index = choice - 1
        method_to_edit = payment_methods_ref[selected_method_index]
        
        print(f"\n--- Editing Payment Method: {method_to_edit.get('name')} ---")
        made_change = False
        
        old_name = method_to_edit.get('name', '')
        new_name = get_input("Payment Method Display Name", default_value=old_name, required=True)
        if new_name != old_name: method_to_edit['name'] = new_name; made_change = True

        if 'instructions' not in method_to_edit or not isinstance(method_to_edit['instructions'], dict):
            method_to_edit['instructions'] = {}; print("Instructions object initialized."); made_change = True

        print("\nEditing instructions (press Enter to keep current value):")
        editable_instructions_config = {}
        if method_to_edit.get('id') == 'kpay':
            editable_instructions_config = {'accountName': "KPay Account Name", 'accountNumber': "KPay Account Number"}
        elif method_to_edit.get('id') == 'binance':
            editable_instructions_config = {'uid': "Binance UID", 'currency': "Accepted Currency"}
        
        for key, prompt_str in editable_instructions_config.items():
            old_value = method_to_edit['instructions'].get(key, '')
            new_value = get_input(prompt_str, default_value=old_value)
            if new_value != old_value: method_to_edit['instructions'][key] = new_value; made_change = True
        
        old_notes = method_to_edit['instructions'].get('notes', '')
        new_notes = get_input("General Notes for instructions", default_value=old_notes)
        if new_notes != old_notes: method_to_edit['instructions']['notes'] = new_notes; made_change = True

        if made_change: print(f"Payment method '{method_to_edit.get('name')}' updated, saving..."); save_data()
        else: print(f"No changes made to payment method '{method_to_edit.get('name')}'.")

# --- Product Management ---
def manage_product_plans(product_ref):
    if 'plans' not in product_ref or not isinstance(product_ref['plans'], list): product_ref['plans'] = []
    made_overall_change_to_plans = False

    while True:
        print(f"\n--- Managing Plans for Product: {product_ref.get('name', 'N/A')} ---")
        if not product_ref['plans']: print("  No plans exist for this product yet.")
        else:
            for i, plan in enumerate(product_ref['plans']):
                stock_status = "Out of Stock" if plan.get('isOutOfStock') else "In Stock"
                print(f"  {i+1}. {plan.get('name', 'N/A')} (${plan.get('price', 0):.2f} / {plan.get('mmksPrice', 0):,} MMKS) - {plan.get('duration', 'N/A')} (Status: {stock_status}) (ID: {plan.get('id')})")
        
        plan_options = ["Add New Plan", "Edit Existing Plan", "Remove Plan", "Toggle Plan Stock Status"]
        choice = display_menu(f"Plan Options for '{product_ref.get('name', 'N/A')}'", plan_options)
        made_change_this_iteration = False

        if choice == 1: 
            print("\n-- Adding New Plan --")
            plan_name = get_input("Plan Name", required=True)
            plan_id_candidate = generate_id(f"{product_ref.get('id','prod').replace('prod_','')}_plan_")
            plan_id = get_input(f"Plan ID (leave blank for auto: {plan_id_candidate})", default_value=plan_id_candidate)
            if not plan_id.strip(): plan_id = plan_id_candidate
            while any(p.get('id') == plan_id for p in product_ref['plans']):
                print(f"Plan ID '{plan_id}' already exists for this product."); plan_id_candidate = generate_id(f"{product_ref.get('id','prod').replace('prod_','')}_plan_")
                plan_id = get_input(f"Plan ID (must be unique, leave blank for auto: {plan_id_candidate})", default_value=plan_id_candidate)
                if not plan_id.strip(): plan_id = plan_id_candidate
            plan_price = get_float_input("Price (USD, e.g., 10.00)", required=True, min_val=0.0)
            plan_mmks_price = get_int_input("Price (MMKS, e.g., 45000)", required=True, min_val=0)
            plan_duration = get_input("Duration (e.g., 1 Month, Lifetime)", required=True)
            plan_is_out_of_stock = get_bool_input("Set this new plan as Out of Stock initially", current_bool_value=False, true_meaning="Out of Stock", false_meaning="In Stock")
            product_ref['plans'].append({"id": plan_id, "name": plan_name, "price": plan_price, "mmksPrice": plan_mmks_price, "duration": plan_duration, "isOutOfStock": plan_is_out_of_stock})
            print(f"Plan '{plan_name}' added."); made_change_this_iteration = True
        elif choice == 2: 
            if not product_ref['plans']: print("No plans to edit."); continue
            print("\n--- Select Plan to Edit ---"); [print(f"  {i+1}. {p.get('name', 'N/A')}") for i, p in enumerate(product_ref['plans'])]
            plan_num = get_int_input("Enter number of plan to edit", required=True, min_val=1, max_val=len(product_ref['plans']))
            if plan_num:
                plan_to_edit = product_ref['plans'][plan_num-1]; print(f"\n-- Editing Plan: {plan_to_edit.get('name')} --"); plan_edited_fields = False
                for key, prompt, p_type, req, min_v in [
                    ('name', "Plan Name", str, True, None), ('price', "Price (USD)", float, True, 0.0),
                    ('mmksPrice', "Price (MMKS)", int, True, 0), ('duration', "Duration", str, True, None)
                ]:
                    old_val = plan_to_edit.get(key)
                    new_val = (get_float_input if p_type == float else get_int_input if p_type == int else get_input)(prompt, default_value=old_val, required=req, min_val=min_v if min_v is not None else None)
                    if new_val != old_val: plan_to_edit[key] = new_val; plan_edited_fields = True
                if plan_edited_fields: made_change_this_iteration = True; print("Plan details updated.")
                else: print("No changes made to plan details.")
        elif choice == 3: 
            if not product_ref['plans']: print("No plans to remove."); continue
            print("\n--- Select Plan to Remove ---"); [print(f"  {i+1}. {p.get('name', 'N/A')}") for i, p in enumerate(product_ref['plans'])]
            plan_num = get_int_input("Enter number of plan to remove", required=True, min_val=1, max_val=len(product_ref['plans']))
            if plan_num:
                plan_to_remove = product_ref['plans'][plan_num-1]
                if get_bool_input(f"Remove plan '{plan_to_remove.get('name')}'?", False, "Yes, Remove", "No, Keep"):
                    product_ref['plans'].pop(plan_num-1); print("Plan removed."); made_change_this_iteration = True
        elif choice == 4: 
            if not product_ref['plans']: print("No plans to toggle stock."); continue
            print("\n--- Select Plan to Toggle Stock Status ---"); [print(f"  {i+1}. {p.get('name', 'N/A')} (Currently: {'Out of Stock' if p.get('isOutOfStock') else 'In Stock'})") for i, p in enumerate(product_ref['plans'])]
            plan_num = get_int_input("Enter number of plan", required=True, min_val=1, max_val=len(product_ref['plans']))
            if plan_num:
                plan_to_toggle = product_ref['plans'][plan_num-1]; current_stock = plan_to_toggle.get('isOutOfStock', False)
                new_stock = get_bool_input(f"Set plan '{plan_to_toggle.get('name')}' to Out of Stock", current_stock, "Out of Stock", "In Stock")
                if new_stock != current_stock: plan_to_toggle['isOutOfStock'] = new_stock; print(f"Plan stock: {'Out of Stock' if new_stock else 'In Stock'}."); made_change_this_iteration = True
                else: print("Plan stock status not changed.")
        elif choice == 5: break 
        if made_change_this_iteration: made_overall_change_to_plans = True; save_data()
        elif choice != len(plan_options) + 1: print("No changes made for this plan action.")
    return made_overall_change_to_plans

def manage_products():
    if 'products' not in site_data or not isinstance(site_data['products'], list): site_data['products'] = []
    products_list_ref = site_data['products']

    while True:
        print("\n--- Product Management ---")
        if not products_list_ref: print("No products exist yet.")
        else:
            print("Current Products:")
            for i, prod in enumerate(products_list_ref):
                stock = " (Overall: Out of Stock)" if prod.get('isOutOfStock') else " (Overall: In Stock)"
                print(f"  {i+1}. {prod.get('name', 'N/A')}{stock} (ID: {prod.get('id', 'N/A')})")
        options = ["View Product Details", "Add New Product", "Edit Existing Product", "Remove Product"]
        choice = display_menu("Product Options", options)
        made_change_at_product_level_direct = False

        if choice == 1: 
            if not products_list_ref: print("No products to view."); continue
            print("\n--- Select Product to View Details ---"); [print(f"  {i+1}. {p.get('name', 'N/A')} (ID: {p.get('id')})") for i,p in enumerate(products_list_ref)]
            prod_num = get_int_input("Enter number of product", required=True, min_val=1, max_val=len(products_list_ref))
            if prod_num:
                prod = products_list_ref[prod_num-1]
                print(f"\n--- Details for: {prod.get('name')} (ID: {prod.get('id')}) ---")
                print(f"Desc: {prod.get('description', 'N/A')}")
                print(f"Stock: {'Out of Stock' if prod.get('isOutOfStock') else 'In Stock'}")
                print("Plans:")
                if prod.get('plans'):
                    for plan in prod['plans']:
                        ps = "Out of Stock" if plan.get('isOutOfStock') else "In Stock"
                        print(f"  - {plan.get('name')} ({plan.get('duration')}): ${plan.get('price',0):.2f} / {plan.get('mmksPrice',0):,}MMKS (Status: {ps}) (ID: {plan.get('id')})")
                else: print("  No plans."); input("\nPress Enter...");
        elif choice == 2: 
            print("\n-- Adding New Product --")
            name = get_input("Product Name", required=True)
            id_cand = generate_id("prod_"); id = get_input(f"Product ID (leave blank for auto: {id_cand})", default_value=id_cand)
            if not id.strip(): id = id_cand
            while any(p.get('id') == id for p in products_list_ref):
                print(f"ID '{id}' exists."); id_cand = generate_id("prod_"); id = get_input(f"Product ID (unique, auto: {id_cand})", default_value=id_cand)
                if not id.strip(): id = id_cand
            desc = get_input("Product Description", required=True)
            oos = get_bool_input("Set new product as Out of Stock initially", False, "Out of Stock", "In Stock")
            new_prod = {"id": id, "name": name, "description": desc, "isOutOfStock": oos, "plans": []}
            print("\nAdd plans for this new product (optional now):")
            manage_product_plans(new_prod) 
            products_list_ref.append(new_prod); print(f"Product '{name}' added."); made_change_at_product_level_direct = True
        elif choice == 3: 
            if not products_list_ref: print("No products to edit."); continue
            print("\n--- Select Product to Edit ---"); [print(f"  {i+1}. {p.get('name', 'N/A')} (ID: {p.get('id')})") for i,p in enumerate(products_list_ref)]
            prod_num = get_int_input("Enter number of product to edit", required=True, min_val=1, max_val=len(products_list_ref))
            if prod_num:
                prod_edit = products_list_ref[prod_num-1]
                product_edited_in_submenu = False 
                while True: 
                    print(f"\n--- Editing: {prod_edit.get('name')} (Stock: {'Out of Stock' if prod_edit.get('isOutOfStock') else 'In Stock'}) ---")
                    edit_opts = ["Name", "Description", "Toggle Product Stock", "Manage Plans for this Product"]
                    edit_choice = display_menu(f"Edit Options for '{prod_edit.get('name')}'", edit_opts)
                    action_taken_sub = False
                    if edit_choice == 1:
                        old, new = prod_edit.get('name',''), get_input("New Name", default_value=prod_edit.get('name',''), required=True)
                        if new != old: prod_edit['name'] = new; action_taken_sub = True
                    elif edit_choice == 2:
                        old, new = prod_edit.get('description',''), get_input("New Desc", default_value=prod_edit.get('description',''), required=True)
                        if new != old: prod_edit['description'] = new; action_taken_sub = True
                    elif edit_choice == 3:
                        curr = prod_edit.get('isOutOfStock', False)
                        new = get_bool_input(f"Set product '{prod_edit.get('name')}' to Out of Stock", curr, "Out of Stock", "In Stock")
                        if new != curr: prod_edit['isOutOfStock'] = new; action_taken_sub = True; print(f"Stock: {'Out of Stock' if new else 'In Stock'}")
                    elif edit_choice == 4: 
                        if manage_product_plans(prod_edit): action_taken_sub = True 
                    elif edit_choice == 5: break 
                    if action_taken_sub: prod_edited_in_submenu = True; print(f"Product '{prod_edit.get('name')}' updated, saving..."); save_data()
                    elif edit_choice != len(edit_opts) + 1: print("No changes for this action.")
                if prod_edited_in_submenu: made_change_at_product_level_direct = True 
        elif choice == 4: 
            if not products_list_ref: print("No products to remove."); continue
            print("\n--- Select Product to Remove ---"); [print(f"  {i+1}. {p.get('name', 'N/A')} (ID: {p.get('id')})") for i,p in enumerate(products_list_ref)]
            prod_num = get_int_input("Enter number of product to remove", required=True, min_val=1, max_val=len(products_list_ref))
            if prod_num:
                prod_rem = products_list_ref[prod_num-1]
                if get_bool_input(f"Remove '{prod_rem.get('name')}' and all its plans?", False, "Yes, Remove", "No, Keep"):
                    products_list_ref.pop(prod_num-1); print("Product removed."); made_change_at_product_level_direct = True
        elif choice == 5: break
        if made_change_at_product_level_direct and (choice == 2 or choice == 4): 
            print("Product list (add/remove) change detected, saving..."); save_data()

# --- Main Program Loop ---
def main_menu():
    menu_options = [
        "Manage Products", "Edit Site Configuration", "Edit Admin Note",
        "Manage FAQs", "Manage Payment Methods"
    ]
    while True:
        choice = display_menu("Main Content Manager Menu", menu_options)
        if choice == 1: manage_products()
        elif choice == 2: manage_site_config()
        elif choice == 3: manage_admin_note()
        elif choice == 4: manage_faqs()
        elif choice == 5: manage_payment_methods()
        elif choice == len(menu_options) + 1: print("Exiting Content Manager."); break

if __name__ == '__main__':
    load_data()
    main_menu()